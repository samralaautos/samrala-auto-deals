const apiKey = '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';
fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [{ role: 'user', content: 'hi' }]
    })
}).then(res => res.json()).then(console.log).catch(console.error);
